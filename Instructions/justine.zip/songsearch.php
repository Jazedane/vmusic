<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
    body {
        font-family: "Georgia", "Times New Roman";
    }

    .main {
        margin-left: 160px;
        /* Same as the width of the sidenav */
        font-size: 28px;
        /* Increased text to enable scrolling */
        padding: 0px 10px;
    }
    </style>
</head>

<body>
    <div class="sidenav">
        <a href="#Song search">Song search</a>
    </div>

</body>

</html>