<html>

<head>
    <style>
    footer {
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: red;
        color: white;
        text-align: center;
    }
    </style>
</head>

<body>

    <footer>
        <p>Juzztine Mañapao 2021</p>
    </footer>

</body>

</html>